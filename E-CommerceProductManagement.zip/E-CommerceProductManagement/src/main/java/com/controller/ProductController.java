package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exception.ResourceNotFoundException;
import com.model.Product;
import com.service.ProductService;

@RestController
@CrossOrigin(origins="http://localhost:3000")
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@PostMapping("/save")
	public ResponseEntity<Product> saveProduct(@RequestBody Product product){
		Product prod=productService.addProduct(product);
		
		return ResponseEntity.status(HttpStatus.CREATED).header("Add", "Added products").body(prod);
	}
	
	@GetMapping("/getAll")
	public ResponseEntity<List<Product>> showAllProduct(){
		List<Product> prodList=productService.getAllProducts();
		return ResponseEntity.ok(prodList);
		
	}
	
	@GetMapping("/getById/{id}")
	public ResponseEntity<Product> showProductById(@PathVariable Long id){
		Optional<Product> prod=productService.getProductById(id);
		
		if(prod.isPresent()) {
			return ResponseEntity.ok(prod.get());
		}
		else {
			return ResponseEntity.notFound().build();
		}
			
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteProductById(@PathVariable Long id){
		boolean deleteprod=productService.deleteProductById(id);
		
		if(deleteprod) {
			return ResponseEntity.ok("product Deleted ");
		}
		else {
			return ResponseEntity.status(404).body("Product not found");
		}
	}
	
	@PutMapping("/update/{id}")
	public ResponseEntity<Product> updateProduct(@PathVariable Long id,@RequestBody Product product){
	
		try {
		Product updateprod=productService.updateProduct(id, product);
		return ResponseEntity.ok(updateprod);
		}catch(ResourceNotFoundException e){
			return ResponseEntity.status(404).body(null);
		}
	
	}
}
