package com.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.ProductRepository;
import com.exception.ResourceNotFoundException;
import com.model.Product;


@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	private ProductRepository productRepository;

	@Override
	public Product addProduct(Product product) {
		
		return productRepository.save(product);
	}

	@Override
	public List<Product> getAllProducts() {
		
		return productRepository.findAll();
	}

	@Override
	public Optional<Product> getProductById(Long id) {
	
		return productRepository.findById(id);
	}

	@Override
	public boolean deleteProductById(Long id) {
		if(productRepository.existsById(id)) {
			productRepository.deleteById(id);
			return true;
		}
		return false;
	}

	@Override
	public Product updateProduct(Long id, Product product) {
		if(productRepository.existsById(id)) {
			product.setId(id);
			return productRepository.save(product);
		}
		else {
			throw new ResourceNotFoundException("Product not found"+id+"not found");
		}
		
	}

}
